from django.apps import AppConfig


class RecomendacionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'recomendacion'
